# how to use

- create a world
- go to Data Packs
- drag `bst_hqmd_vX.X.X` into the thing and enable it
- if the world is already created, go to your world folder
- put it in the `datapacks` folder

- go to Resource Packs in your settings
- drag `bst_hqmd_vX.X.X` into the thing and enable it
- if you're using essential you can put it in shared packs in the `Host` menu
- if you're hosting an actual server just learn how to do `server.properties` man
